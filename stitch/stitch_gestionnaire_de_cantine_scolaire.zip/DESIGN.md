---
name: Canteen Operations System
colors:
  surface: '#fbf8ff'
  surface-dim: '#d5d8f9'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#ececff'
  surface-container-high: '#e5e6ff'
  surface-container-highest: '#dee0ff'
  on-surface: '#161a32'
  on-surface-variant: '#404943'
  inverse-surface: '#2b2f48'
  inverse-on-surface: '#f0efff'
  outline: '#707973'
  outline-variant: '#bfc9c1'
  surface-tint: '#2c694e'
  primary: '#0f5238'
  on-primary: '#ffffff'
  primary-container: '#2d6a4f'
  on-primary-container: '#a8e7c5'
  inverse-primary: '#95d4b3'
  secondary: '#9b4500'
  on-secondary: '#ffffff'
  secondary-container: '#fc8a40'
  on-secondary-container: '#672c00'
  tertiary: '#005503'
  on-tertiary: '#ffffff'
  tertiary-container: '#206e1b'
  on-tertiary-container: '#9cee8a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b1f0ce'
  primary-fixed-dim: '#95d4b3'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#0e5138'
  secondary-fixed: '#ffdbc9'
  secondary-fixed-dim: '#ffb68d'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#763300'
  tertiary-fixed: '#a4f792'
  tertiary-fixed-dim: '#89da79'
  on-tertiary-fixed: '#002201'
  on-tertiary-fixed-variant: '#005303'
  background: '#fbf8ff'
  on-background: '#161a32'
  surface-variant: '#dee0ff'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
The design system is built on the pillars of efficiency and vitality. It targets a dual audience: busy administrative staff who require high-density data management and students/parents who need a frictionless, welcoming experience. 

The aesthetic is **Modern Corporate with a Human Touch**. It utilizes heavy whitespace to reduce cognitive load in busy kitchen environments and uses a systematic approach to color to signal health and freshness. The interface feels dependable yet approachable, moving away from "institutional" vibes toward a contemporary, health-focused service application.

## Colors
The palette is rooted in "Nutritious Greens" and "Appetite Oranges."
- **Primary (#2D6A4F):** A deep, professional forest green used for headers, primary actions, and branding. It conveys stability and health.
- **Secondary (#FF8C42):** A warm, energetic orange used sparingly for high-priority calls to action and meal highlights. It is designed to stimulate appetite and draw attention.
- **Tertiary (#74C365):** A vibrant leaf green used for success states, nutritional badges (e.g., "Vegan", "Healthy Choice"), and positive growth in data visualizations.
- **Neutrals:** A range of soft grays (from #F8F9FA to #4A4E69) are used for backgrounds and text to maintain a clean, high-contrast reading environment.

## Typography
This design system utilizes **Inter** for its exceptional legibility and systematic weight distribution.
- **Headlines:** Use Semi-Bold (600) for structural clarity. Large headlines should use slight negative letter spacing to feel more cohesive on digital screens.
- **Body Text:** Standardized at 16px for optimal reading on both desktop and mobile. 
- **Data/Labels:** Small labels use Medium (500) or Semi-Bold (600) weights to ensure they remain legible when used in dense admin tables or compact meal cards.

## Layout & Spacing
The design system follows a **Fluid Grid** model with an 8px base unit. 
- **Desktop:** A 12-column grid with 24px gutters. Sidebars for admin panels are fixed at 280px, while the main content area expands.
- **Mobile:** A 4-column grid with 16px margins.
- **Spacing Rhythm:** Use `md (24px)` for internal card padding and `lg (32px)` for vertical section spacing to maintain an airy, clean feel.

## Elevation & Depth
Depth is created through **Tonal Layers** and **Ambient Shadows** rather than harsh borders.
- **Level 0 (Background):** Soft gray (#F8F9FA) to reduce glare.
- **Level 1 (Cards/Surface):** Pure white (#FFFFFF) with a very soft, diffused shadow (0px 4px 20px rgba(0, 0, 0, 0.05)).
- **Level 2 (Hover/Active):** Slightly deeper shadow (0px 8px 30px rgba(0, 0, 0, 0.08)) to indicate interactivity.
- **Outlines:** Use 1px borders in a very light gray (#E9ECEF) for form inputs and secondary containers to maintain structure without adding visual noise.

## Shapes
The shape language is consistently **Rounded**, reflecting a friendly and safe environment.
- **Standard (8px):** Used for buttons, input fields, and small cards.
- **Large (16px):** Used for main meal option cards and modal containers.
- **Pill (Full):** Used exclusively for status chips (e.g., "In Stock", "Allergy Alert") and global search bars.

## Components
- **Meal Cards:** White background, 16px border radius, soft shadow. Images should have a subtle 4px internal radius. Titles in `headline-md`, price in `body-lg` (Primary Green).
- **Primary Buttons:** Solid Primary Green background, white text, 8px radius. High-emphasis actions like "Checkout" or "Add Meal."
- **Secondary Buttons:** Ghost style with a 1px Primary Green border and green text.
- **Input Fields:** 8px radius, 1px light gray border. On focus, the border transitions to Primary Green with a 2px soft glow.
- **Status Chips:** Small, pill-shaped badges. Use Tertiary Green for "Healthy," Secondary Orange for "Low Stock," and a muted red for "Allergens."
- **Data Visualizations:** Use a clean, sans-serif font for axis labels. Charts should use the Primary, Secondary, and Tertiary palette for consistency.
- **Navigation:** A clean top-bar for students/parents and a persistent left-hand rail for admin users to facilitate quick switching between "Inventory," "Orders," and "Reports."